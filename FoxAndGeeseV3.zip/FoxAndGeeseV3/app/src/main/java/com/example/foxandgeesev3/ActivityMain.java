package com.example.foxandgeesev3;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityMain extends AppCompatActivity {

    private ImageView[] piecesTop = new ImageView[4];
    private ImageView pieceBottom;
    private int[] piecesTopRows = {0, 0, 0, 0}; // Starting at the top row
    private int[] piecesTopCols = {1, 3, 5, 7}; // Starting on black squares
    private int pieceBottomRow = 7; // Starting at the bottom row
    private int pieceBottomCol = 2; // Starting on a black square
    private boolean isPieceSelected;

    private int selectedPieceIndex = -1;
    private boolean isTopPieceSelected = false;
    private boolean isTopTurn = false; // True if it's the top pieces' turn, false if it's the bottom piece's turn

    private boolean firstMove = false;
    private int gridSize = 8;
    private int cellSize;
    private final int HIGHLIGHT_COLOR = Color.YELLOW; // Highlight color
    private final int NO_HIGHLIGHT_COLOR = Color.TRANSPARENT; // No highlight color
    private TextView winningMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        GridLayout gridLayout = findViewById(R.id.chessboard);
        winningMessage = findViewById(R.id.winning_message);
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        cellSize = Math.min(screenWidth, screenHeight) / gridSize;

        // Create the chessboard
        for (int row = 0; row < gridSize; row++) {
            for (int col = 0; col < gridSize; col++) {
                ImageView cell = new ImageView(this);
                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = cellSize;
                params.height = cellSize;
                cell.setLayoutParams(params);

                if ((row + col) % 2 == 0) {
                    cell.setBackgroundColor(Color.WHITE);
                } else {
                    cell.setBackgroundColor(Color.BLACK);
                }

                final int finalRow = row;
                final int finalCol = col;
                cell.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        handleCellClick(finalRow, finalCol);
                    }
                });

                gridLayout.addView(cell);
            }
        }

        // Create and place the bottom piece
        pieceBottom = new ImageView(this);
        pieceBottom.setImageResource(R.drawable.fox); // Set the image resource for the bottom piece
        GridLayout.LayoutParams pieceBottomParams = new GridLayout.LayoutParams();
        pieceBottomParams.width = cellSize;
        pieceBottomParams.height = cellSize;
        pieceBottomParams.rowSpec = GridLayout.spec(pieceBottomRow);
        pieceBottomParams.columnSpec = GridLayout.spec(pieceBottomCol);
        pieceBottom.setLayoutParams(pieceBottomParams);


        pieceBottom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isTopTurn) { // Only allow selection if it's the bottom piece's turn
                    isPieceSelected = true;
                    isTopPieceSelected = false;
                    highlightPiece(pieceBottom);
                }
            }
        });

        gridLayout.addView(pieceBottom);

        // Create and place the top pieces
        for (int i = 0; i < 4; i++) {
            piecesTop[i] = new ImageView(this);
            piecesTop[i].setImageResource(R.drawable.goose); // Set the image resource for the top pieces
            GridLayout.LayoutParams pieceTopParams = new GridLayout.LayoutParams();
            pieceTopParams.width = cellSize;
            pieceTopParams.height = cellSize;
            pieceTopParams.rowSpec = GridLayout.spec(piecesTopRows[i]);
            pieceTopParams.columnSpec = GridLayout.spec(piecesTopCols[i]);
            piecesTop[i].setLayoutParams(pieceTopParams);

            final int index = i;
            piecesTop[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isTopTurn) { // Only allow selection if it's the top pieces' turn
                        isPieceSelected = true;
                        isTopPieceSelected = true;
                        selectedPieceIndex = index;
                        highlightPiece(piecesTop[index]);
                    }
                }
            });

            gridLayout.addView(piecesTop[i]);
        }
    }

    private void handleCellClick(int row, int col) {
        if (isPieceSelected) {
            if (isTopPieceSelected) {
                if (isValidTopMove(row, col, selectedPieceIndex)) {
                    piecesTopRows[selectedPieceIndex] = row;
                    piecesTopCols[selectedPieceIndex] = col;
                    updatePiecePosition(selectedPieceIndex);
                    isPieceSelected = false;
                    isTopTurn = false; // Switch turn to bottom piece
                    removeHighlight();
                    if (checkBottomPlayerMove()) {
                        showWinningMessage("Geese win");

                    }
                }
            } else {
                if (isValidBottomMove(row, col)) {
                    pieceBottomRow = row;
                    pieceBottomCol = col;
                    updateBottomPiecePosition();
                    if (pieceBottomRow == 0) { // Check if bottom piece reaches the top row
                        showWinningMessage("Fox wins");


                    } else {
                        isPieceSelected = false;
                        isTopTurn = true; // Switch turn to top pieces
                    }
                    removeHighlight();
                }
            }
        }
    }

    private boolean isValidTopMove(int row, int col, int index) {
        int rowDiff = row - piecesTopRows[index];
        int colDiff = Math.abs(col - piecesTopCols[index]);
        return rowDiff == 1 && colDiff == 1; // Only move diagonally downwards
    }

    private boolean isValidBottomMove(int row, int col) {
        int rowDiff = Math.abs(row - pieceBottomRow);
        int colDiff = Math.abs(col - pieceBottomCol);
        return rowDiff == 1 && colDiff == 1; // Only move diagonally
    }

    private void updatePiecePosition(int index) {
        GridLayout.LayoutParams pieceParams = (GridLayout.LayoutParams) piecesTop[index].getLayoutParams();
        pieceParams.rowSpec = GridLayout.spec(piecesTopRows[index]);
        pieceParams.columnSpec = GridLayout.spec(piecesTopCols[index]);
        piecesTop[index].setLayoutParams(pieceParams);
    }

    private void updateBottomPiecePosition() {
        GridLayout.LayoutParams pieceParams = (GridLayout.LayoutParams) pieceBottom.getLayoutParams();
        pieceParams.rowSpec = GridLayout.spec(pieceBottomRow);
        pieceParams.columnSpec = GridLayout.spec(pieceBottomCol);
        pieceBottom.setLayoutParams(pieceParams);
    }

    private void highlightPiece(ImageView piece) {
        removeHighlight();
        piece.setBackgroundColor(HIGHLIGHT_COLOR);
    }

    private void removeHighlight() {
        // Remove highlight from all pieces
        pieceBottom.setBackgroundColor(NO_HIGHLIGHT_COLOR);
        for (ImageView piece : piecesTop) {
            piece.setBackgroundColor(NO_HIGHLIGHT_COLOR);
        }
    }

    private void resetGame() {
        // Reset positions
        pieceBottomRow = 7;
        pieceBottomCol = 2;
        pieceBottom.setImageResource(R.drawable.fox);
        updateBottomPiecePosition();


        for (int i = 0; i < 4; i++) {

                piecesTopRows[i] = 0;
                piecesTopCols[i] = i*2+1;
                piecesTop[i].setImageResource(R.drawable.goose);
                updatePiecePosition(i);

        }

        isPieceSelected = false;
        selectedPieceIndex = -1;
        isTopPieceSelected = false;
        firstMove ^= true;
        isTopTurn = firstMove;
        removeHighlight();
        winningMessage.setVisibility(View.GONE); // Hide winning message
    }

    private boolean checkBottomPlayerMove() {
        boolean hasValidMove = false;
        int[][] directions = {{-1, -1}, {-1, 1}, {1, -1}, {1, 1}};
        for (int[] direction : directions) {
            int newRow = pieceBottomRow + direction[0];
            int newCol = pieceBottomCol + direction[1];
            if (newRow >= 0 && newRow < gridSize && newCol >= 0 && newCol < gridSize) {
                boolean isOccupied = false;
                for (int i = 0; i < 4; i++) {
                    if (piecesTopRows[i] == newRow && piecesTopCols[i] == newCol) {
                        isOccupied = true;
                        break;
                    }
                }
                if (!isOccupied) {
                    hasValidMove = true;
                    break;
                }
            }
        }
        return !hasValidMove; // Return true if no valid moves
    }

    private void showWinningMessage(String message) {
        winningMessage.setText(message);
        winningMessage.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                resetGame();
            }
        }, 2000); // Restart game after 2 seconds
    }
}
